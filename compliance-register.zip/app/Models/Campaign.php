<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Campaign extends Model
{
    protected $table = "campaigns";

    protected $fillable = [
        'campaigner_id', 'assembly_id', 'event_category_id', 'event_category_others', 'address', 'campaign_date',
        'remarks', 'permission_status', 'last_date_of_permission', 'keywords', 'status','rescheduled_at','cancelled_remarks',
    ];


    // public function campaigner(){
    //     return $this->belongsTo(Campaigner::class, 'campaigner_id', 'id');
    // }

    public function campaigners()
    {
        return $this->belongsToMany(
            Campaigner::class,
            'event_campaigners',
            'campaign_id',
            'campaigner_id'
        )->withTimestamps();
    }

    public function assembly(){
        return $this->belongsTo(Assembly::class, 'assembly_id', 'id');
    }

    public function category(){
        return $this->belongsTo(EventCategory::class, 'event_category_id', 'id');
    }
    public function permissions(){
        return $this->hasMany(CampaignWisePermission::class, 'campaign_id', 'id');
    }

    public function documents()
    {
        return $this->hasMany(CampaignPermissionDocument::class, 'campaign_id');
    }

}
