<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\App;
use App\Livewire\{
    AdminDashboard,
    PhaseWiseDistrict,
    ZoneCrud,
    PhaseCrud,
    EventCategoryCrud,
    EmployeeCrud,
    AssemblyList,
    CandidateContactList,
    CandidateDocumentCollection,
    CandidateDocumentPreview,
    CandidateDocumentVetting,
    DiscrepancyReportCrud,
    CandidateJourney,
    CandidateForm5Update,
    AgentCrud,
    AdminLogin,
    CampaignCrud,
    PermissionCampaignCrud,
    ForgetPassword,
    UpdateProfile,
    ChangePassword,
    NotificationList,
    RolePermissions,
    StarCampaignerCrud,
    EventWiseDistrict,
    MccViolationCrud,
    MccViolationCrudRemarks,
    MccLogDetails,
    PhaseWiseMcc,
    NominationForm2B,
    NominationForm2BPreview,
    Form26,
    Form26Preview,
    NominationDocumentCrud,
    GradeWiseAssemblyCrud,
    WarRoomCrud,
    WarRoomCrudRemarks,
    ObservationFormPreview,
    Form2BLogPreview,
};
use App\Http\Controllers\NominationPdfController;
use App\Livewire\Candidate\DocumentComments;
use App\Http\Controllers\NotificationController;

Route::middleware('site.down')->group(function () {
/*
|--------------------------------------------------------------------------
| Language Switch Route
|--------------------------------------------------------------------------
| This lets the user change language (English ↔ Bengali) by clicking a
| toggle button. It stores the chosen language in the session.
*/
Route::get('/lang/{locale}', function ($locale) {
    if (in_array($locale, ['en', 'bn'])) {
        Session::put('locale', $locale);
        App::setLocale($locale);
    }
    return redirect()->back();
})->name('lang.switch');

/*
|--------------------------------------------------------------------------
| Root Redirect
|--------------------------------------------------------------------------
*/
Route::get('/', function () {
    if (Auth::guard('admin')->check()) {
        return redirect()->route('admin.dashboard');
    }
    return redirect()->route('login');
});

/*
|--------------------------------------------------------------------------
| Admin Login (guest)
|--------------------------------------------------------------------------
*/
Route::get('/login', AdminLogin::class)
    ->middleware('guest:admin')
    ->name('login');

Route::get('/forget/password',ForgetPassword::class)->name('forget.password');

/*
|--------------------------------------------------------------------------
| Authenticated Admin Routes
|--------------------------------------------------------------------------
| These are protected routes for logged-in admins only.
| The SetLocale middleware (registered in bootstrap/app.php) ensures
| text is displayed in the selected language.
*/
Route::prefix('/admin')->middleware('auth:admin')->group(function () {
    Route::get('/dashboard', AdminDashboard::class)->name('admin.dashboard')->middleware('employee.permission:view_dashboard');
    Route::get('/update/profile', UpdateProfile::class)->name('admin.update.profile');
    Route::get('/change-password', ChangePassword::class)->name('admin.change.password');
    Route::get('/notifications', NotificationList::class)->name('admin.notifications');
    Route::get('phase/{phaseId}/district', PhaseWiseDistrict::class)->name('admin.phasewise.district');
    Route::get('phase/{phaseId}/mcc', PhaseWiseMcc::class)->name('admin.phasewise.mcc');
    Route::get('/eventwise/district', EventWiseDistrict::class)->name('admin.eventwise.district');

    // Route::get('/notifications/latest', [NotificationController::class, 'latest']);
    Route::post('/notifications/mark-read/{id}', [NotificationController::class, 'markRead']);
    
    Route::prefix('master')->group(function () {
        Route::get('/zones', ZoneCrud::class)->name('admin.master.zones')->middleware('employee.permission:master_view_zones');
        Route::get('/phases', PhaseCrud::class)->name('admin.master.phases')->middleware('employee.permission:master_view_phases');
        Route::get('/event-categories', EventCategoryCrud::class)->name('admin.master.eventcategory')->middleware('employee.permission:master_view_event_categories');
        Route::get('/nomination-documents', NominationDocumentCrud::class)->name('admin.master.nomination-documents')->middleware('employee.permission:master_view_nomination_documents');
        Route::get('/grade-wise-assembly', GradeWiseAssemblyCrud::class)->name('admin.master.grade-wise-assembly');
    });

    Route::prefix('/employees')->group(function (){
        Route::get('/', EmployeeCrud::class)->name('admin.employees')->middleware('employee.permission:employee_view_employee');
        Route::get('/permissions/{id}', RolePermissions::class)->name('admin.employees.permissions');
    });

    Route::get('/assemblies', AssemblyList::class)->name('admin.assemblies')->middleware('employee.permission:assembly_view_assembly');
    Route::get('/contacts', AgentCrud::class)->name('admin.agents')->middleware('employee.permission:contact_view_contacts');
    
    Route::prefix('candidates')->group(function () {
        Route::get('/journey/{id}', CandidateJourney::class)->name('admin.candidates.journey');
       // Route::get('/form-5/{id}', CandidateForm5Update::class)->name('admin.candidates.form5');
        Route::get('/form-2B/{id}', NominationForm2B::class)->name('admin.candidates.form2B');
        Route::get('/form-2B/{id}/preview', NominationForm2BPreview::class)->name('admin.candidates.form2B.preview');
        Route::get('/form-26/{id}', Form26::class)->name('admin.candidates.form26');
        Route::get('/form-26/{id}/preview',Form26Preview::class)->name('admin.candidates.form26.preview');
        Route::get('/form-2B/pdf/{id}', [NominationPdfController::class, 'download'])->name('admin.candidates.form2B.pdf');
        Route::get('/form-26/pdf/{id}', [NominationPdfController::class, 'downloadPdf'])->name('admin.candidates.form26.pdf');
        Route::get('/nomination-log/pdf/{log}',[NominationPdfController::class, 'downloadFromLog'])->name('admin.candidates.log.pdf');
        Route::get('/form2b-preview/{logId}', Form2BLogPreview::class)->name('admin.form2b.preview.log');
        Route::get('/nominations', CandidateContactList::class)->name('admin.candidates.contacts')->middleware('employee.permission:nomination_view_candidate');
        Route::get('/social-media', DiscrepancyReportCrud::class)->name('admin.candidates.discrepancies.report');
        Route::get('/documents', CandidateDocumentCollection::class)->name('admin.candidates.documents')->middleware('employee.permission:nomination_document_repository');
        Route::get('/documents/preview', CandidateDocumentPreview::class)->name('admin.candidates.documents.preview')->middleware('employee.permission:nomination_document_preview');
        Route::get('/documents/comments/{document}', DocumentComments::class)->name('admin.candidates.documents.comments');
        Route::get('/documents/vetting/{document}', CandidateDocumentVetting::class)->name('admin.candidates.documents.vetting');
        // Route::get('/observation-form/{id}', [NominationPdfController::class, 'observationForm'])->name('admin.candidates.observation.form');
        Route::get('/observation-form/{id}', ObservationFormPreview::class)->name('admin.candidates.observation.form');
        Route::post('/observation-pdf/{id}', [NominationPdfController::class, 'observationPdf'])->name('admin.candidates.observation.pdf');

    });


    Route::prefix('campaign')->group(function (){
        Route::get('/', CampaignCrud::class)->name('admin.campaigns')->middleware('employee.permission:campaign_view_campaign');
        Route::get('/permission/{campaign_id}', PermissionCampaignCrud::class)->name('admin.campaigns.permission')->middleware('employee.permission:campaign_campaign_permission');
        Route::get('/star-campaigner', StarCampaignerCrud::class)->name('admin.campaigns.star-campaigner');
    });

    Route::prefix('mcc-violation')->group(function (){
        Route::get('/', MccViolationCrud::class)->name('admin.mcc_violation')->middleware('employee.permission:mcc_view_mcc');
        Route::get('/remarks/{id}', MccViolationCrudRemarks::class)->name('admin.mcc_violation_remarks')->middleware('employee.permission:mcc_violation_remarks');
        Route::get('/log-details/{id}', MccLogDetails::class)->name('admin.mcc_log_details');
    });
    Route::prefix('war-room')->group(function (){
        Route::get('/', WarRoomCrud::class)->name('admin.war_room')->middleware('employee.permission:war_room_view');
        Route::get('/remarks/{id}', WarRoomCrudRemarks::class)->name('admin.war_room_remarks')->middleware('employee.permission:war_room_remarks_view');
    });
});

Route::post('/api/whatsapp/webhook', [NotificationController::class, 'receiveIncident']);
Route::get('/api/whatsapp/webhook', function () {
    return response()->json([
        'status' => false,
        'message' => 'Not Permission'
    ], 403);
});
/*
|--------------------------------------------------------------------------
| API Route Example
|--------------------------------------------------------------------------
*/
/*
|--------------------------------------------------------------------------
| Logout
|--------------------------------------------------------------------------
*/
Route::post('/store-device-id', function (\Illuminate\Http\Request $request) {
    session(['device_id' => $request->device_id]);
    return response()->json(['status' => 'ok']);
});
Route::post('/logout', function () {
    Auth::guard('admin')->logout();
    request()->session()->invalidate();
    request()->session()->regenerateToken();
    return redirect('/login');
})->name('admin.logout');

});